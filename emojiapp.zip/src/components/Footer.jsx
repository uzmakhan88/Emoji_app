

const Footer = () => {
    return (  
        <footer>
            <p className="author">👧  by <a href="https://github.com/garu2" target="_blank">Uzma</a></p>
        </footer>
    );
}
 
export default Footer;